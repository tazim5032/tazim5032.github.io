const s=new Set(["P","DIV","SECTION","ARTICLE","H1","H2","H3","H4","H5","H6","UL","OL","TABLE","TR","BLOCKQUOTE","HEADER","FOOTER"]),u=new Set(["SCRIPT","STYLE","NOSCRIPT","TEMPLATE","SVG","BUTTON","IFRAME","FORM"]);function f(t){const e=[],o=n=>{if(n.nodeType===3){e.push(n.textContent??"");return}if(n.nodeType!==1)return;const r=n;if(!(u.has(r.tagName)||r.getAttribute("aria-hidden")==="true")){if(r.tagName==="BR")return void e.push(`
`);r.tagName==="LI"?e.push(`
- `):s.has(r.tagName)&&e.push(`

`);for(const c of r.childNodes)o(c);s.has(r.tagName)&&e.push(`
`)}};return o(t),a(e.join(""))}function d(t,e){if(!/[<&]/.test(t))return a(t);const n=new DOMParser().parseFromString(`<div>${t}</div>`,"text/html").body.firstElementChild??e.createElement("div");return f(n)}function a(t){return t.replace(/\u00a0/g," ").split(`
`).map(e=>e.replace(/[ \t]+/g," ").trim()).join(`
`).replace(/^- $/gm,"").replace(/\n{3,}/g,`

`).trim()}function p(t){const e=[],o=t.ownerDocument.createTreeWalker(t,4);for(let n=o.nextNode();n;n=o.nextNode()){const r=n.parentElement;r&&(r.closest('script,style,noscript,[aria-hidden="true"]')||r.tagName==="BUTTON")||e.push(n.textContent??"")}return l(e.join(" "))}const l=t=>(t??"").replace(/\s+/g," ").trim();function h(...t){const e=t.filter(Boolean).join(" ").toLowerCase();return/\bhybrid\b/.test(e)?"hybrid":/\b(fully remote|remote[- ]first|100% remote|work from home|wfh|remote)\b/.test(e)?"remote":/\b(on[- ]?site|in[- ]office|in office)\b/.test(e)?"onsite":null}const i=String.raw`(?:[$€£¥₹৳]|USD|EUR|GBP|CAD|AUD|INR|BDT)\s?\d[\d,.]*\s?[kKmM]?`,m=new RegExp(String.raw`${i}(?:\s*(?:-|–|—|to)\s*${i}|\s*(?:-|–|—|to)\s*\d[\d,.]*\s?[kKmM]?)?(?:\s*(?:per|/|an?)\s*(?:year|yr|annum|month|mo|hour|hr|week))?`,"i");function T(t){return t.match(m)?.[0].trim()??null}export{l as c,h as d,f as e,T as f,d as h,p as s,a as t};
